# Admin panel endpoints package
